# Activity 4: [Insert Exact Activity Title]

## Description
Replace this section with a short description based on the original Activity 4 instructions and submitted output.

## What I Learned
Write 3–5 sentences based on the actual activity. Include the main skill or concept learned, one challenge and how it was addressed, and how the skill can be applied or improved in the future.

## Files
Add the original Activity 4 documentation and output files to this folder.
