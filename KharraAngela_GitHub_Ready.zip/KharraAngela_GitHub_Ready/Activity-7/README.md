# Activity 7: Resume Generation Using ChatGPT

## Description
This activity used ChatGPT to organize information from an existing nursing student resume into a clear, concise, and professional format. The goal was to highlight educational background, related clinical learning experiences, certifications, and relevant professional references.

## What I Learned
I learned how an AI tool can help organize resume information into a more readable and professional format. Reviewing the generated resume also showed me the importance of checking accuracy and making sure that the details reflect my actual background and experiences. One important part of the process was evaluating the AI-generated content rather than relying on it without review. I can apply these skills when preparing future applications and continue improving my resume as I gain more clinical and professional experience.

## Files
Add `Kharra_Angela_Sta_Maria_Resume_Activity_Final.pdf` and any separate final resume file to this folder.
