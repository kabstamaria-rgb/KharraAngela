# Before uploading to GitHub

1. Add your profile photo to the root folder and name it `profile-photo.jpg`.
2. Add the original activity files to their matching folders.
3. Confirm the exact title and content of Activity 4, then replace the placeholder README.
4. Check that Activity 1–3 titles match the final PDFs you intend to submit.
5. Keep only one copy of duplicate PDFs.
6. Upload the folder contents to `https://github.com/kabstamaria-rgb/KharraAngela`.
7. Use clear commit messages such as `Add Activity 1 presentation design documentation`.
8. Confirm the repository is Public and the README image and file links work.
