# Activity 2: Color Palette and Typography

## Description
This activity explored how color palettes and typography contribute to the appearance, readability, and overall message of a digital design.

## What I Learned
I learned that colors can establish a visual mood and help create consistency across a design. I also learned that typography affects readability, tone, and the way viewers understand information. Choosing colors and fonts that complement each other makes a design more organized and effective. I can apply these skills when creating presentations, infographics, and other digital materials.

## Files
Add the original Activity 2 PDF and design outputs to this folder.
