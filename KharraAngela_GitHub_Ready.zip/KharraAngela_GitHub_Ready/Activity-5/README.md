# Activity 5: Improving AI Prompts and Comparing Outputs

## Description
This activity used ChatGPT in the education and student productivity domain, focusing on effective time management for students. It compared the response to a general prompt with the response generated after improving the prompt to make it more specific and useful.

## What I Learned
I learned that the way a prompt is written can affect the relevance, detail, and usefulness of an AI-generated response. Comparing the original and improved outputs helped me see how adding context and clear instructions can produce a more focused answer. I also learned to evaluate AI responses instead of accepting them automatically. In future tasks, I can use clearer prompts and review generated information carefully before applying it.

## Files
Add the original PDF, prompt screenshots, and output comparison materials to this folder.
