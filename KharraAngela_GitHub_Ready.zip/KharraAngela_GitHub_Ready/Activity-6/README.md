# Activity 6: Making a Website – Personal Portfolio

## Description
This activity involved creating a one-page personal portfolio website using a website-building tool. The portfolio presents academic information, nursing student experiences, skills, and selected projects in an organized digital format.

## What I Learned
Through this activity, I learned how a personal portfolio can present information in an organized and creative way. Creating the website helped me understand the importance of layout, color combination, readability, and selecting relevant content for an online audience. I was also able to connect my academic experiences and developing skills into one digital presentation. This activity improved my confidence in using digital tools and showed me how technology can communicate personal and academic growth.

## Files
Add `STA_MARIA_ACTIVITY6_PORTFOLIO.html`, `STA_MARIA_ACTIVITY6.pdf`, and the website screenshots to this folder.
