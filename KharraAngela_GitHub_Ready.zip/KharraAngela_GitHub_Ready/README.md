# Kharra Angela Sta. Maria

**Bachelor of Science in Nursing**  
**Ateneo de Davao University**  
**Expected Graduation: 2027**

![Profile photo](profile-photo.jpg)

## About Me
I am a Bachelor of Science in Nursing student at Ateneo de Davao University. This repository presents selected outputs from my GE 4120 / 21st Century IT Skills activities, highlighting my development in digital communication, visual design, artificial intelligence tools, and website creation.

## Skills and Tools
- Presentation and visual design principles
- Color selection and typography
- Infographic and social media content development
- Prompt writing and refinement using AI tools
- Comparing AI-generated outputs
- Website planning and creation
- Resume development with AI assistance
- GitHub repository organization and documentation

## Course Activities
| Folder | Activity |
|---|---|
| [Activity 1](Activity-1/README.md) | Presentation Design Principles |
| [Activity 2](Activity-2/README.md) | Color Palette and Typography |
| [Activity 3](Activity-3/README.md) | Social Media Infographics and Mini Project Documentation |
| [Activity 4](Activity-4/README.md) | Add the exact Activity 4 title |
| [Activity 5](Activity-5/README.md) | Improving AI Prompts and Comparing Outputs |
| [Activity 6](Activity-6/README.md) | Making a Website: Personal Portfolio |
| [Activity 7](Activity-7/README.md) | Resume Generation Using ChatGPT |

---
*GE 4120 – 21st Century IT Skills*
