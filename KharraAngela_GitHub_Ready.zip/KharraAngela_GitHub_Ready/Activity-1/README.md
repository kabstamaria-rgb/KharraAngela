# Activity 1: Presentation Design Principles

## Description
This activity focused on applying essential presentation design principles to make information clear, organized, and visually effective. Key concepts included balance, alignment, contrast, consistency, white space, and visual hierarchy.

## What I Learned
I learned that an effective presentation is not only about the information being shared but also about how that information is arranged. Applying balance, alignment, contrast, consistency, and white space helps make slides easier to understand. I also learned to use visual hierarchy to guide the audience toward the most important points. In future presentations, I can apply these principles to communicate ideas more clearly and improve the overall appearance of my work.

## Files
Add the original activity documentation and related output files to this folder.
