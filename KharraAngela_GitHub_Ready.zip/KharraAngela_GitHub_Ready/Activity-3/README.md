# Activity 3: Social Media Infographics and Mini Project Documentation

## Description
This activity involved developing social media infographic content and documenting the mini project. It emphasized presenting information in a visual format that is organized and understandable to an online audience.

## What I Learned
I learned how to arrange information into a concise visual format suitable for social media. I also learned that an infographic should have a clear message, readable text, and visual elements that support the topic. Preparing project documentation helped me keep track of the process and present the output clearly. I can use these skills to create informative digital materials for academic activities and future health education projects.

## Files
Add the original Activity 3 documentation, infographic, and related images to this folder.
